using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class User : MonoBehaviour
{
  // private void OnTriggerEnter2D(Collider2D other){
  //     Debug.Log("Detection successful");
  // }
  //  private void OnCollisionEnter2D(Collision2D other){
  //     Debug.Log("Detection successful");
  // }

  public int level = 1;
  public int[] scores = new int[]{0,0,0,0,0};
  void Update(){
   // print("Button is pressed ig !!!");
  }

  
}
